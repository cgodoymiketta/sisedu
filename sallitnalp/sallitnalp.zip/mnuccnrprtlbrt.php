<table width="100%" border="0">
	<tr>
	  <td width="40%" height="16"><input type="hidden" name="vlccn" value="<?=$vlccn; ?>"> &nbsp; </td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	</tr>
</table>
