<table width="100%" border="0">
					  <tr>
						<td width="85%"  align="left"><strong><font face="Times New Roman, Times, serif" size="2" color="#3300FF" > <a href="perfil.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>">Perfiles </a></font></strong></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><strong><font face="Times New Roman, Times, serif" size="2" color="#3300FF" ><a href="usrusuario.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>">Usuarios</a></font></strong></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><strong><font face="Times New Roman, Times, serif" size="2" color="#3300FF" >Cargos</font></strong></td>
					  </tr>
					</table>