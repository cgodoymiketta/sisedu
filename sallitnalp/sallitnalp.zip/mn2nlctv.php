<table width="100%" border="0">
					  <tr>
						<td width="85%"  align="left"><a href="anolectivo.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >A&ntilde;o Lectivo</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="seccurso.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Cursos
						        - Especialidad</font></strong></a></td>
					  </tr>
					  <tr>
						<td width="85%" height="15"  align="left"><a href="distributivomat.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Distributivo Mat.</font></strong></a></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="distributivoparl.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Distributivo Parl.</font></strong></a></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><hr></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="estudiante.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Estudiantes</font></strong></a> </td>
					  </tr>
						<tr>
						<td width="85%"  align="left"><a href="inscripcion.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Inscripci&oacute;n</font></strong></a> </td>
                      </tr>					  
                      <tr>
						<td width="85%"  align="left"><a href="matricula.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Matr&iacute;culas</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="secadminismatricula.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Cambios de Estado</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><hr></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"> <a href="secdocente.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" >Docentes</font></strong></a></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="distributivodocent.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" > Distributivo Dcte</font></strong></a></td>
					  </tr><tr>
						<td width="85%"  align="left"><a href="secdocentemateria.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#990000" > Docente - Materia</font></strong></a></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><hr></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="secretaria.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font color="#990000" size="2" face="Times New Roman, Times, serif">Horarios</font></strong></a></td>
					  </tr>
                      <tr>
						<td width="85%"  align="left"><a href="secquimestre.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font color="#990000" size="2" face="Times New Roman, Times, serif">Quimestre</font></strong></a></td>
					  </tr>
                      <tr>
						<td width="85%"  align="left"><a href="secparcial.php?nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font color="#990000" size="2" face="Times New Roman, Times, serif">Parcial</font></strong></a></td>
					  </tr>
					</table>