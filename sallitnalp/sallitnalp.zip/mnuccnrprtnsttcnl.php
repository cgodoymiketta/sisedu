<table width="100%" border="0">
	<tr>
	  <td width="5%" height="16"><input type="hidden" name="vlccn" value="<?=$vlccn; ?>"> &nbsp; </td>
      <!-----------------------------REPORTES CUANDO EL ESTUDIANTE ESTE MATRICULADO ------->
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
      <!-----------------------------HASTA AQUI LOS REPORTES ------->
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	</tr>
</table>
