<table width="100%" border="0">
					  <tr>
						<td width="85%"  align="left"><a href="extension.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#000000" > Extension</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="especialidad.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#000000" > Especialidad</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><strong><a href="curso.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><font face="Times New Roman, Times, serif" size="2" color="#000000" >Curso</font></a></strong></td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="paralelo.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#000000" >Paralelo</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="familia.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#000000" >Familia - Materia</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><a href="materia.php?vlccn=listado&nlctv=<?php echo $VLAnoLocal; ?>&nsttcn=<?php echo $VLInstitucion; ?>&sr=<?php echo $VLUsuario; ?>"><strong><font face="Times New Roman, Times, serif" size="2" color="#000000" >Materia</font></strong></a> </td>
					  </tr>
					  <tr>
						<td width="85%"  align="left"><strong><font face="Times New Roman, Times, serif" size="2" color="#000000" >Aulas</font></strong></td>
					  </tr>
					</table>