<table width="100%" border="0">
	<tr>
	  <td width="40%" height="16"><input type="hidden" name="vlccn" value="<?=$vlccn; ?>"> &nbsp; </td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%">&nbsp;</td>
	  <td width="10%"><input name="buscar" type="image" id="buscar" onClick="sumit" src="imagenes/027-folder_searchx24.gif" alt="Buscar" width="24" height="24" border="0" value="buscar"></td>
	  <td width="10%"><input name="imprimir" type="image" id="imprimir" onClick="sumit" src="imagenes/Printer%204_24x24-32.gif" alt="Imprimir" width="24" height="24" border="0" value="imprimir"></td>
	  <td width="10%">&nbsp;</td>
	</tr>
</table>
