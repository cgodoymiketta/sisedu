<form name="form1" method="get" action="docquimestre.php">


<table width="1000" border="0">
  <tr>
    <td width="50">&nbsp;</td>
    <td width="900"><?php include("mn1dctqmstr.php"); ?> </td>
    <td width="50">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>
	<table width="100%" border="0">
      <tr>
	  	<td height="290">
		  <table width="100%" border="1">
		  <tr>
			<td width="15%" height="290"  valign="top"><?php include("mn2dctqmstr.php"); ?>&nbsp;</td>
			<td width="85%" align="center"  valign="top"><?php include("dts1dctqmstr.php"); ?>&nbsp;
			  </td>
		  </tr>
		  </table>
	  	</td>
      </tr>
    </table>
	  </td>
    <td>&nbsp;</td>
  </tr>
</table>
</form>
